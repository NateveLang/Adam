class Definition():
	def __init__(): # Do not remove this function, Definition must not be void
		return "done"