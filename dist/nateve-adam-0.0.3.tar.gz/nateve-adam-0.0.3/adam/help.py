introducing_text = """
Welcome to Nateve language!

        888b    888        d8888 88888888888 8888888888 888     888 8888888888 
        8888b   888       d88888     888     888        888     888 888        
        88888b  888      d88P888     888     888        888     888 888        
        888Y88b 888     d88P 888     888     8888888    Y88b   d88P 8888888    
        888 Y88b888    d88P  888     888     888         Y88b d88P  888        
        888  Y88888   d88P   888     888     888          Y88o88P   888        
        888   Y8888  d8888888888     888     888           Y888P    888        
        888    Y888 d88P     888     888     8888888888     Y8P     8888888888


                            8888  8888  8888  8888  8888
                            8888  8888  8888  8888  8888 


                            8888  8888  8888  8888  8888
                            8888  8888  8888  8888  8888
                            8888  8888  8888  8888  8888
                            8888  8888  8888  8888  8888
                            8888  8888  8888  8888  
                            8888  8888  8888
                            8888  8888  
                            8888  8888  
                            8888  8888
                            8888
                            8888
                            8888

Nateve is a new general domain programming language open source inspired by languages like Python, C++, JavaScript, and Wolfram Mathematica.

Nateve is an transpiled language. Its first transpiler, Adam, is fully built using Python 3.8.

For detailed info, see the [Nateve documentation](https://nateve.readthedocs.io/).
"""