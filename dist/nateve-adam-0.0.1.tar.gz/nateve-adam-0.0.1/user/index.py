from user.definitions import Definition
Index = { 
'__init__': Definition.__init__,  # Do not remove this function, Index must not be void
}
